<?php

namespace App\Services;

class BotFernando
{
    public function process()
    {

    }

}
