<?php

use Illuminate\Support\Facades\Route;

Route::get('/', 'BotFernandoController@index');
Route::post('/', 'BotFernandoController@index');
